.. toctree::
   :maxdepth: 2
.. include:: ../../README.rst
   :end-before: ----
Class Documentation
===================
.. doxygenclass:: FirebaseArduino
   :project: firebase-arduino
   :members:
.. doxygenclass:: FirebaseObject
   :project: firebase-arduino
   :members:
----
This documentation was built using ArduinoDocs_.
.. _ArduinoDocs: http://arduinodocs.readthedocs.org
